# Zem Bot — Setup

A separate bot from Paysy. Commands: /forexprice, /forexalert, /ask — plus it auto-replies whenever someone types "zem" in chat.

## 1. Database
In Supabase SQL Editor, run schema.sql (just adds one new table, safe to run even though you already have other tables from Paysy).

## 2. Deploy on Render (same as Paysy)
1. Create a new GitHub repo, upload this whole folder
2. Render → New + → Web Service → Free plan → connect the repo
3. Build command: npm install / Start command: npm start
4. Add these Environment Variables:

DISCORD_TOKEN=MTU1MDQ2NzAyNDU0NTc3OTc4Mw.Gm1kNQ.G4N6oNGuYtJlzyGSMMlpjDQzWHAS-E0fo83Zc0
DISCORD_CLIENT_ID=1550467024545779783
GUILD_ID=1515274357516013719
FOREX_ALERTS_CHANNEL_ID=1550462727988977815
ECONOMIC_CALENDAR_CHANNEL_ID=1550462944402477098
NVIDIA_API_KEY=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
SUPABASE_URL=https://xjpapwndqdaejogmvjer.supabase.co
SUPABASE_SECRET_KEY=(your Supabase secret key from before)

5. Deploy, watch logs for "Logged in as ..." and "Slash commands registered."
6. Set up a second UptimeRobot monitor pinging THIS bot's Render URL too (separate from Paysy's), so it doesn't sleep.

## 3. Invite the bot
Developer Portal → your Zem app → OAuth2 → URL Generator → check "bot" + "applications.commands" → permission "Send Messages" → open link → add to Cryptoarea.
